public class Books {
    private String title;
    private String author;
    private int publicYrs;
    private int ISBN;
    private int callNum;
    private String location;

    /* ===== Constructor ===== */
    public Books(String title, String author, int publicYrs, int ISBN, int callNum, String location) {
        this.title = title;
        this.author = author;
        this.publicYrs = publicYrs;
        this.ISBN = ISBN;
        this.callNum = callNum;
        this.location = location;
    }

    /* ===== Getter ===== */
    public String getTitle() {
        return title;
    }

    public String getAuthor() {
        return author;
    }

    public int getPublicYrs() {
        return publicYrs;
    }

    public int getISBN() {
        return ISBN;
    }

    public int getCallNum() {
        return callNum;
    }

    public String getLocation() {return location;}

    /* ===== Setter ===== */
    public void setTitle(String title) {
        this.title = title;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public void setPublicYrs(int publicYrs) {
        this.publicYrs = publicYrs;
    }

    public void setCallNum(int callNum) {
        this.callNum = callNum;
    }

    public void setISBN(int ISBN) {
        this.ISBN = ISBN;
    }

    public void setLocation(String location) {this.location = location;}


    public String toString() {
        return "Title: " + this.title +
                " | Author: " + this.author +
                " | publication Years: " + this.publicYrs +
                " | ISBN: " + this.ISBN +
                " | call number: " + this.callNum +
                " | Location: " + this.location;
    }
}
